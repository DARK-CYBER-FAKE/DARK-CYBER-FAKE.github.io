<html>
   <head>
   <title>Count Down Download dengan JavaScript</title>
   <script type="text/javascript">  
    var counter = 10; 
    function countDown(){       
        if(counter>=0){
            document.getElementById("timer").innerHTML = counter;
        }
        else{ 
            download(); 
            return; 
        }
        counter -= 1; 
        var counter2 = setTimeout("countDown()",1000); 
        return; 
    } 
     
    function download(){ 
        document.getElementById("link").innerHTML = "<a href='http://namasitus/filedownload'>Download</a>";
    } 
   </script>
   </head>
   <body>
        <h1>File Download</h1>
 
        <h3>Link download akan muncul dalam <span id="timer"></span> detik.</h3>
        <p><span id="link"></span></p>
</body>
   </html>